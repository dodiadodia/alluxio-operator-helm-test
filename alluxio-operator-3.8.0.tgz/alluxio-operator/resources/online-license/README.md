# Online license agent TLS credentials

The chart supports three credential workflows. Use exactly one of them.

The Agent always verifies the License Service server certificate. For public
CA/ACM/ALB endpoints, leave
`licenseController.onlineLicenseAgent.caSecretName` empty and the container
system trust store is used. For QA, in-cluster Service, or private-CA
endpoints, create a Secret containing `ca.crt` and set `caSecretName`:

```sh
kubectl -n alluxio-operator create secret generic online-license-service-ca \
  --from-file=ca.crt=/secure/path/ca.crt

helm upgrade --install operator ./deploy/charts/alluxio-operator \
  --set licenseController.onlineLicenseAgent.enabled=true \
  --set licenseController.onlineLicenseAgent.serviceURL=https://license-service.example \
  --set licenseController.onlineLicenseAgent.caSecretName=online-license-service-ca
```

The CA Secret must contain the `ca.crt` key. Do not use `http://` endpoints or
disable certificate verification.

When enabled, the online license Agent uses the same image as the Operator;
no separate Agent image is required.

The Agent identifies this Operator installation by the Kubernetes UID of the
release namespace. That identity remains stable across Agent Pod replacement
and Helm upgrades, but deleting and recreating the namespace deliberately
creates a new Agent identity in the License Service.

## Helm `--set-file` (recommended)

Keep the downloaded files outside the chart and pass both files at install or
upgrade time:

```sh
helm upgrade --install operator ./deploy/charts/alluxio-operator \
  --set licenseController.onlineLicenseAgent.enabled=true \
  --set-file licenseController.onlineLicenseAgent.crt=/secure/path/tls.crt \
  --set-file licenseController.onlineLicenseAgent.key=/secure/path/tls.key
```

The chart creates the Kubernetes TLS Secret named by
`licenseController.onlineLicenseAgent.credentialSecretName` in the release
namespace.

## Chart resource files

For a local chart install, place the customer Agent credential downloaded from
the License Service admin UI in this directory:

- `tls.crt`
- `tls.key`

When both files are present, the chart creates the Kubernetes TLS Secret named
by `licenseController.onlineLicenseAgent.credentialSecretName` in the release
namespace. Keep these files out of source control and do not package or share a
chart that contains customer credentials; use `--set-file` for the normal
workflow.

## Pre-created Secret

If neither the values nor the chart resource files provide both credentials,
the chart assumes the Secret already exists and mounts it by name:

```sh
kubectl -n alluxio-operator create secret tls license-agent-tls \
  --cert=/secure/path/tls.crt \
  --key=/secure/path/tls.key
```

Supplying only one of `crt` or `key` is rejected during Helm rendering.
